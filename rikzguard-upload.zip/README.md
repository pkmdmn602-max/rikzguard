# RIKZGUARD V2

Bot WhatsApp group guard berbasis Baileys untuk Node.js 20+.

## Fitur inti
- Anti-jorok: hapus pesan + warning, tanpa kick.
- Anti-link.
- Anti-flood/spam.
- Anti-tag berlebihan.
- Anti-caps.
- Welcome & goodbye.
- Admin moderation.
- Per-group config.
- Menu 4 halaman dengan 100+ slot command/fitur.
- Pairing code, sehingga nomor bot dapat ditautkan sebagai perangkat WhatsApp.

## Instalasi di Debian/Termux

```bash
cd ~/rikzguard-v2
npm install
npm start
```

Saat pertama jalan, masukkan nomor WhatsApp dengan format:
`628xxxxxxxxxx`

Lalu di WhatsApp:
Perangkat tertaut -> Tautkan perangkat -> Tautkan dengan nomor telepon

## Catatan
Bot harus menjadi admin grup agar bisa menghapus pesan anggota atau menjalankan aksi admin.
Untuk keamanan, jangan bagikan folder `session/` karena berisi kredensial login.

## Contoh
`.menu`
`.menu 2`
`.antijorok on`
`.antilink on`
`.antispam on`
`.warn @user`
`.warnings`
`.rules`
`.tagall`
