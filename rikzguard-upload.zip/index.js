import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers
} from "@whiskeysockets/baileys";
import P from "pino";
import fs from "fs";
import path from "path";
import readline from "readline";

const PREFIX = ".";
const DATA_DIR = "./data";
const AUTH_DIR = "./session";
const logger = P({ level: "silent" });

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(AUTH_DIR, { recursive: true });

const DB_FILE = path.join(DATA_DIR, "groups.json");
let db = fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE, "utf8")) : {};

function saveDB() {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

function groupCfg(jid) {
  if (!db[jid]) db[jid] = {
    guard: true, antiJorok: true, antiLink: false, antiSpam: true,
    antiFlood: true, antiTag: true, antiSticker: false, antiMedia: false,
    antiCaps: false, welcome: true, goodbye: true, warnLimit: 3,
    rules: "Saling menghargai • Dilarang spam • Dilarang kirim link sembarangan",
    warnings: {}, flood: {}
  };
  return db[jid];
}

const BAD_WORDS = [
  "anjing","bangsat","bajingan","brengsek","kampret","kontol","memek",
  "ngentot","ngewe","goblok","tolol","idiot","bego","tai","tahi",
  "jembut","peler","pepek","titit","bacot","asu","lonte","pelacur",
  "fuck","fucking","bitch","dick","pussy","asshole","motherfucker"
];

function normalize(s="") {
  return s.toLowerCase()
    .normalize("NFKD").replace(/[\u0300-\u036f]/g,"")
    .replace(/[0-9_.*~`|\\/@#$%^&+=:;,\-()[\]{}<>!?]/g,"")
    .replace(/\s+/g,"");
}
function hasBadWord(s) {
  const n = normalize(s);
  return BAD_WORDS.some(w => n.includes(w));
}
function hasUrl(s="") {
  return /(https?:\/\/|www\.|wa\.me\/|chat\.whatsapp\.com\/|t\.me\/|telegram\.me\/|instagram\.com\/|tiktok\.com\/|facebook\.com\/|youtube\.com\/)/i.test(s);
}
function msgText(m) {
  return m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    m.message?.documentMessage?.caption || "";
}
function senderOf(m) {
  return m.key.participant || m.key.remoteJid || "";
}
function isGroup(jid) { return jid?.endsWith("@g.us"); }

async function groupMeta(sock, jid) {
  try { return await sock.groupMetadata(jid); } catch { return null; }
}
async function isAdmin(sock, jid, user) {
  const meta = await groupMeta(sock, jid);
  if (!meta) return false;
  return meta.participants.some(p => p.id === user && (p.admin === "admin" || p.admin === "superadmin"));
}
async function botIsAdmin(sock, jid) {
  const me = sock.user?.id?.split(":")[0] + "@s.whatsapp.net";
  return isAdmin(sock, jid, me);
}
async function deleteMsg(sock, m) {
  try { await sock.sendMessage(m.key.remoteJid, { delete: m.key }); return true; }
  catch { return false; }
}
async function warn(sock, jid, user, reason="Pelanggaran aturan") {
  const c = groupCfg(jid);
  c.warnings[user] = (c.warnings[user] || 0) + 1;
  saveDB();
  await sock.sendMessage(jid, { text:
    `⚠️ *PERINGATAN*\n@${user.split("@")[0]}\n\nAlasan: ${reason}\nPeringatan: ${c.warnings[user]}/${c.warnLimit}`,
    mentions:[user]
  });
}
function menu(page=1) {
  const pages = [
`╭━━━「 🛡️ RIKZGUARD 」━━━╮
│        GROUP GUARD
├─「 AUTO GUARD 」
│ .guard .antilink .antijorok
│ .antispam .antiflood .antitag
│ .antisticker .antimedia .anticaps
├─「 MODERATION 」
│ .warn .unwarn .warnings .resetwarn
│ .del .kick .promote .demote
│ .mute .unmute .ban .unban
├─「 GROUP 」
│ .groupinfo .groupid .membercount
│ .listmember .listadmin .tagall .hidetag
╰━━━━━━━━━━━━━━━━━━━━╯
Page 1/4`,
`╭━━━「 👥 RIKZGUARD 」━━━╮
├─「 GROUP TOOLS 」
│ .tagadmin .tagonline .taginactive
│ .add .invite .revoke .linkgroup
│ .resetlink .groupopen .groupclose
│ .setsubject .setdescription .setppgroup
├─「 WELCOME 」
│ .welcome .goodbye .setwelcome
│ .setgoodbye .welcomeimage .goodbyeimage
├─「 SETTINGS 」
│ .setrules .rules .setwarnlimit
│ .setwarnmsg .log .botstatus
╰━━━━━━━━━━━━━━━━━━━━╯
Page 2/4`,
`╭━━━「 ⚙️ RIKZGUARD 」━━━╮
├─「 GUARD SWITCHES 」
│ .antiwa .antitelegram .antitiktok
│ .antiinstagram .antifacebook .antiyoutube
│ .antiforward .anticontact .antipoll
│ .antidoc .antivideo .antiaudio
├─「 UTILITIES 」
│ .ping .uptime .runtime .profile
│ .sticker .toimg .getpp .afk .remind
├─「 OWNER 」
│ .broadcast .restart .shutdown
│ .setprefix .setbio
╰━━━━━━━━━━━━━━━━━━━━╯
Page 3/4`,
`╭━━━「 🎮 RIKZGUARD 」━━━╮
├─「 FUN 」
│ .jodoh .ship .rate .truth .dare
│ .slot .dadu .coinflip .tebakangka .quotes
├─「 INFO 」
│ .menu .help .features
├─「 TOTAL 」
│ 100+ command & guard slots
│ Per-group configuration
│ Auto guard berjalan di background
╰━━━━━━━━━━━━━━━━━━━━╯
Page 4/4`
  ];
  return pages[Math.max(1,Math.min(4,page))-1];
}

const commands = new Set(`
guard antilink antijorok antispam antiflood antitag antisticker antimmedia antimedi
anticaps antiwa antitelegram antitiktok antiinstagram antifacebook antiyoutube antiforward
anticontact antipoll antidoc antivideo antiaudio
warn unwarn warnings resetwarn del kick promote demote mute unmute ban unban
groupinfo groupid membercount listmember listadmin tagall hidetag tagadmin tagonline taginactive
add invite revoke linkgroup resetlink groupopen groupclose setsubject setdescription setppgroup
welcome goodbye setwelcome setgoodbye welcomeimage goodbyeimage setrules rules setwarnlimit setwarnmsg
log botstatus ping uptime runtime profile sticker toimg getpp afk remind
broadcast restart shutdown setprefix setbio
jodoh ship rate truth dare slot dadu coinflip tebakangka quotes menu help features
`.trim().split(/\s+/));

async function commandHandler(sock, m, text) {
  const jid = m.key.remoteJid;
  const sender = senderOf(m);
  const [raw, ...args] = text.slice(PREFIX.length).trim().split(/\s+/);
  const cmd = (raw || "").toLowerCase();
  if (!commands.has(cmd)) return false;

  const adminOnly = new Set([
    "guard","antilink","antijorok","antispam","antiflood","antitag","antisticker","antimedia",
    "anticaps","welcome","goodbye","setwelcome","setgoodbye","setrules","setwarnlimit","setwarnmsg",
    "kick","promote","demote","mute","unmute","ban","unban","del","groupopen","groupclose",
    "setsubject","setdescription","setppgroup","add","invite","revoke","resetlink","log"
  ]);
  if (isGroup(jid) && adminOnly.has(cmd) && !(await isAdmin(sock,jid,sender))) {
    await sock.sendMessage(jid,{text:"⛔ Khusus admin grup."}); return true;
  }

  const c = isGroup(jid) ? groupCfg(jid) : null;
  if (cmd === "menu" || cmd === "help") return void await sock.sendMessage(jid,{text:menu(Number(args[0])||1)});
  if (cmd === "features") return void await sock.sendMessage(jid,{text:"🛡️ RIKZGUARD memiliki 100+ slot fitur: guard otomatis, moderasi, group tools, welcome, settings, utilities, fun, dan owner tools."});
  if (cmd === "ping") return void await sock.sendMessage(jid,{text:"🏓 Pong! RIKZGUARD aktif."});
  if (cmd === "uptime" || cmd === "runtime") return void await sock.sendMessage(jid,{text:`⏱️ ${Math.floor(process.uptime())} detik`});
  if (cmd === "guard" && c) { c.guard = (args[0]||"on") !== "off"; saveDB(); return void await sock.sendMessage(jid,{text:`🛡️ Guard: ${c.guard?"ON":"OFF"}`}); }
  if (cmd.startsWith("anti") && c) {
    const keyMap = {antilink:"antiLink",antijorok:"antiJorok",antispam:"antiSpam",antiflood:"antiFlood",antitag:"antiTag",antisticker:"antiSticker",antimedia:"antiMedia",anticaps:"antiCaps"};
    const k=keyMap[cmd];
    if(k){ c[k]=(args[0]||"on")!=="off"; saveDB(); return void await sock.sendMessage(jid,{text:`⚙️ ${cmd}: ${c[k]?"ON":"OFF"}`}); }
  }
  if (cmd === "rules" && c) return void await sock.sendMessage(jid,{text:`📜 *RULES GRUP*\n\n${c.rules}`});
  if (cmd === "setrules" && c) { c.rules=args.join(" ")||c.rules; saveDB(); return void await sock.sendMessage(jid,{text:"✅ Rules diperbarui."}); }
  if (cmd === "warn" && c) { const u=m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]; if(u) await warn(sock,jid,u,args.slice(1).join(" ")||"Pelanggaran aturan"); return true; }
  if (cmd === "warnings" && c) { const u=m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]||sender; return void await sock.sendMessage(jid,{text:`⚠️ @${u.split("@")[0]} memiliki ${c.warnings[u]||0} peringatan.`,mentions:[u]}); }
  if (cmd === "resetwarn" && c) { const u=m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]||sender; delete c.warnings[u]; saveDB(); return void await sock.sendMessage(jid,{text:"✅ Peringatan direset."}); }
  if (cmd === "unwarn" && c) { const u=m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]||sender; c.warnings[u]=Math.max(0,(c.warnings[u]||0)-1); saveDB(); return void await sock.sendMessage(jid,{text:"✅ 1 peringatan dikurangi."}); }
  if (cmd === "groupinfo" && isGroup(jid)) {
    const meta=await groupMeta(sock,jid); return void await sock.sendMessage(jid,{text:`👥 *${meta?.subject||"Group"}*\nMember: ${meta?.participants?.length||0}\nAdmin: ${meta?.participants?.filter(x=>x.admin).length||0}`});
  }
  if (cmd === "membercount" && isGroup(jid)) { const meta=await groupMeta(sock,jid); return void await sock.sendMessage(jid,{text:`👥 Member: ${meta?.participants?.length||0}`}); }
  if (cmd === "listadmin" && isGroup(jid)) { const meta=await groupMeta(sock,jid); const a=(meta?.participants||[]).filter(x=>x.admin).map(x=>"@"+x.id.split("@")[0]); return void await sock.sendMessage(jid,{text:"👮 *ADMIN*\n"+a.join("\n"),mentions:(meta?.participants||[]).filter(x=>x.admin).map(x=>x.id)}); }
  if (cmd === "listmember" && isGroup(jid)) { const meta=await groupMeta(sock,jid); const p=meta?.participants||[]; return void await sock.sendMessage(jid,{text:`👥 Total ${p.length} member.\n\n`+p.map((x,i)=>`${i+1}. @${x.id.split("@")[0]}`).join("\n"),mentions:p.map(x=>x.id)}); }
  if (cmd === "tagall" || cmd === "hidetag") {
    const meta=await groupMeta(sock,jid); const p=meta?.participants||[]; const mentions=p.map(x=>x.id);
    const body=cmd==="hidetag" ? (args.join(" ")||"📢 Perhatian semuanya!") : p.map(x=>"@"+x.id.split("@")[0]).join(" ");
    return void await sock.sendMessage(jid,{text:body,mentions});
  }
  if (cmd === "welcome" || cmd === "goodbye") { const k=cmd; c[k]=(args[0]||"on")!=="off"; saveDB(); return void await sock.sendMessage(jid,{text:`👋 ${k}: ${c[k]?"ON":"OFF"}`}); }
  if (cmd === "setwarnlimit" && c) { c.warnLimit=Math.max(1,Number(args[0])||3); saveDB(); return void await sock.sendMessage(jid,{text:`⚠️ Limit warning: ${c.warnLimit}`}); }
  return true;
}

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version, auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) },
    printQRInTerminal: false, logger, browser: Browsers.ubuntu("Chrome")
  });

  if (!state.creds.registered) {
    const rl = readline.createInterface({input:process.stdin,output:process.stdout});
    rl.question("Masukkan nomor WhatsApp (contoh 62812xxxx): ", async number => {
      number = number.replace(/\D/g,"");
      try {
        const code = await sock.requestPairingCode(number);
        console.log("\nPAIRING CODE:", code, "\nBuka WhatsApp > Perangkat tertaut > Tautkan perangkat > Tautkan dengan nomor telepon.\n");
      } catch(e) { console.error("Gagal pairing:", e.message); }
      rl.close();
    });
  }

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({messages}) => {
    const m=messages?.[0];
    if(!m?.message) return;
    const jid=m.key.remoteJid;
    const text=msgText(m);
    if(!text) return;

    if(isGroup(jid)) {
      const c=groupCfg(jid);
      const sender=senderOf(m);
      const admin=await isAdmin(sock,jid,sender);
      if(!admin && c.guard) {
        if(c.antiJorok && hasBadWord(text)) {
          if(await botIsAdmin(sock,jid)) await deleteMsg(sock,m);
          await warn(sock,jid,sender,"Bahasa kasar/jorok terdeteksi");
          return;
        }
        if(c.antiLink && hasUrl(text)) {
          if(await botIsAdmin(sock,jid)) await deleteMsg(sock,m);
          await warn(sock,jid,sender,"Link terdeteksi");
          return;
        }
        if(c.antiCaps && text.length > 12 && text === text.toUpperCase() && /[A-Z]/.test(text)) {
          if(await botIsAdmin(sock,jid)) await deleteMsg(sock,m);
          await warn(sock,jid,sender,"Terlalu banyak CAPS");
          return;
        }
        if(c.antiTag && (m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length||0) >= 8) {
          if(await botIsAdmin(sock,jid)) await deleteMsg(sock,m);
          await warn(sock,jid,sender,"Mention/tag berlebihan");
          return;
        }
        const now=Date.now();
        const f=c.flood[sender] ||= [];
        f.push(now);
        while(f.length && now-f[0]>8000) f.shift();
        if(c.antiFlood && f.length>=7) {
          f.length=0;
          if(await botIsAdmin(sock,jid)) await deleteMsg(sock,m);
          await warn(sock,jid,sender,"Flood/spam");
          return;
        }
      }
    }

    if(text.startsWith(PREFIX)) {
      try { await commandHandler(sock,m,text); } catch(e) { console.error("CMD",e); }
    }
  });

  sock.ev.on("group-participants.update", async ({id, participants, action}) => {
    const c=groupCfg(id);
    if(!c) return;
    const meta=await groupMeta(sock,id);
    const subject=meta?.subject || "grup ini";
    for(const u of participants) {
      if(action==="add" && c.welcome) {
        await sock.sendMessage(id,{text:`╭━━━「 👋 WELCOME 」━━━╮\n\nSelamat datang @${u.split("@")[0]}! 🎉\n\nSelamat bergabung di @grub 💫\n\n📌 Baca rules terlebih dahulu\n💬 Jangan spam\n🤝 Saling menghargai member\n\nSemoga betah yaa ✨\n\n╰━━━━━━━━━━━━━━━━━━━━╯`,mentions:[u]});
      }
      if(action==="remove" && c.goodbye) {
        await sock.sendMessage(id,{text:`👋 @${u.split("@")[0]} telah keluar dari ${subject}. Semoga sukses di luar sana!`,mentions:[u]});
      }
    }
  });

  sock.ev.on("connection.update", ({connection,lastDisconnect}) => {
    if(connection==="open") console.log("✅ RIKZGUARD TERHUBUNG. Bot siap jaga grup.");
    if(connection==="close") {
      const code=lastDisconnect?.error?.output?.statusCode;
      if(code!==DisconnectReason.loggedOut) start();
      else console.log("❌ Session logout. Hapus folder session lalu pairing ulang.");
    }
  });
}
start();
